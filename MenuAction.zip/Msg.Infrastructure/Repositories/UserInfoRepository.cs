﻿using Msg.Core.Interfaces;
using Msg.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace Msg.Infrastructure.Repositories
{
    public class UserInfoRepository : EfRepository<UserInfo>, IUserInfoRepository
    {
        public UserInfoRepository(BaseContext dbcontext) : base(dbcontext)
        {

        }
        /// <summary>
        /// 获取用户
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public UserInfo CheckUser(string userName, string password)
        {
            return List(x => x.UserName == userName && x.Password == password).FirstOrDefault() ?? new UserInfo() { UserName = "哈哈哈哈" };
        }
    }
}
