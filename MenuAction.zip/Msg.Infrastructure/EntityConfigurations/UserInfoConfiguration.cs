﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Msg.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace Msg.Infrastructure.EntityConfigurations
{
    public class UserInfoConfiguration : EntityBaseConfiguration<UserInfo>
    {
        public override void ConfigureDerived(EntityTypeBuilder<UserInfo> b)
        {
            //根据自己情况看着瞎写吧  就这样 不BB
        }
    }
}
