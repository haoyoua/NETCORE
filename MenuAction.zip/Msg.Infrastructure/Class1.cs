﻿using System;

namespace Msg.Infrastructure
{
    public class Class1
    {
    }
}
