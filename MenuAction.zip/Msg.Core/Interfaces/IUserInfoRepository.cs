﻿using Msg.Infrastructure.Data;
using Msg.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Msg.Core.Interfaces
{
    public interface IUserInfoRepository : IRepository<UserInfo>
    {
        /// <summary>
        /// 检查用户是存在
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="password">密码</param>
        /// <returns>存在返回用户实体，否则返回NULL</returns>
        UserInfo CheckUser(string userName, string password);
    }
}
